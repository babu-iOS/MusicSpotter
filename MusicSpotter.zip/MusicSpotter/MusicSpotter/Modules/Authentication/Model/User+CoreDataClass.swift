//
//  User+CoreDataClass.swift
//  MusicSpotter
//
//  Created by IOS-Babu on 10/05/24.
//
//

import Foundation
import CoreData

@objc(User)
public class User: NSManagedObject {

}
